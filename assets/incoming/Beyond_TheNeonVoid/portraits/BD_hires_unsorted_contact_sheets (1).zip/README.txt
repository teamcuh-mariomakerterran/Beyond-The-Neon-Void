Unsorted leftover Imagine files — contact_sheets.
