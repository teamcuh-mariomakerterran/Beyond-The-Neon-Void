Black Doctrine icon kit
-----------------------
Transparent PNG. Icons are authored at 32px and nearest-neighbored to 64px cells.
Sheets are exact 64px grids, no gutter, so the intake wizard can slice on cell size.

icons_64/   individual 64x64
icons_32/   individual 32x32 nearest downsample
sheets/     packed sprite sheets (*_64.png) plus dark previews
hud/        bars, pips, tile diamonds (64x32), banners, card frame, 9-slice panel, damage numbers
manifest.json  names in sheet order

command_states_64.png rows: move, attack, wait, item, cards, act
states left to right: normal, hover, pressed, disabled, cooldown

Rarity frames are hollow and sit behind any icon.
