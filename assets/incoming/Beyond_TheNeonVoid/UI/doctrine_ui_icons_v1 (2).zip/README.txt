BLACK DOCTRINE — UI ICON DROP v1
Style: LOD example density (charcoal body, orange rim, cyan gem, hard pixels).
Frames: acid lime corners, purple hazard stripes, rivets. Matches ui_frame refs.

LAYOUT
- icons_64/   individual transparent PNGs, 64x64 cell, icon fitted inside with nearest-neighbor
- icons_32/   same icons, nearest half (intake can use either)
- sheets/     packed grids, EXACT 64px cells, 0 margin, row-major. Slice on 64 boundaries.
- frames/     tooltip, dialog, banner. Transparent center. Not 9-slice yet — decorative plates.
- hud/        HP/MP bars (empty + fill), AP pips, level badge, START/VICTORY/DEFEAT/TURN plates
- manifest.json  id -> file map
- PREVIEW_all_icons_dark.png  contact sheet

NAMING
Ability types: attack magic heal buff debuff utility special
Elements: plasma electric tech cryo void essence kinetic physical
Weapons: sword katana heavy_blade knife knuckles baton lance rod staff codex pistol rifle laser_gun heavy_gun injector cyberdeck wrench controller synth ribbon shield
Rarity frames (hollow): common uncommon rare epic legendary
Statuses: haste fortified inspired focused regen hidden dualcast charging berserk rewind_anchor / stun knockdown stop slow exposed short_circuit demoralized blinded shocked burning poisoned asleep essence_bleed fading unstable identity_loss delay_thread stitched buzzed silence
Classes: 36 emblems, see manifest (chrome_warrior ... black_doctrine_enforcer). Names are the production set — swap ids if the data table differs.
Commands: move act wait item cards attack_cmd capture repair
Button states: btn_normal btn_hover btn_pressed btn_disabled btn_cooldown

NOT IN THIS DROP (wave 2)
Signature move overlays (~40), crafting mat set, damage-number font, exploration minimap pins, full form controls (slider, checkbox, scrollbar), 9-slice source cuts, JUMP/EVA stat icons, soul-coin currency.
Godot: import filter Nearest, repeat Disabled, alpha Transparent.
