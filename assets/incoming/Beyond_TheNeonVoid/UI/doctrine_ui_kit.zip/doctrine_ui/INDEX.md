# Doctrine UI kit — pass 1 (starred)

Transparent PNGs. No pink field left in the files. Intake wizard slice: row-major, 64×64, no gap, origin top-left.

## icons_64/
One file per glyph. 64×64, nearest-neighbor fit, 3px pad.

- ability_* (7): attack, magic, heal, buff, debuff, utility, special
- element_* (8): plasma, electric, tech, cryo, void, essence, kinetic, physical
- weapon_* (21): sword through shield
- class_* / enemy_* (12 core emblems, not the full 36)
- buff_* (10) and debuff_* (20, includes silence)
- rarity_* (5 hollow frames: common iron, uncommon lime, rare cobalt, epic amethyst, legendary amber)
- armor_* , gear_accessory, gear_trinket
- item_* : hp_stim, mp_stim, cleanse, revive, buff_shot, neon_gin
- sys_* , stat_* , cmd_* , currency_soul_coin, currency_microchip

## sheets/
Packed copies of the same cells. `sheet_<group>_64.png` is the slice target.
`preview_*.png` is a labeled contact on a dark plate — do not slice the previews.

## button_states/
Move / Act / Wait / Item / Cards × normal, hover, pressed, disabled.
`sheets/sheet_command_states_64.png` is 4 columns (states) by 5 rows (commands).

## numbers/
0–9, plus, minus in white / damage / heal / crit. 16×16 cells.
Banners: CRIT, HEAL, MISS, BLOCK, START, VICTORY, DEFEAT, TURN.

## hud_pieces/
Battle frame scraps in the lime/purple rivet language: unit card, bars, pips, facing arrows, cover, LOS eye, range diamonds. Not 9-slice yet.

## Not in this pass
Full 36 jobs, signature moves, crafting mats, data disks, iso 64×32 tile markers, card hand, exploration plates, controller glyphs, production 9-slice (your existing frame set still owns that job).
