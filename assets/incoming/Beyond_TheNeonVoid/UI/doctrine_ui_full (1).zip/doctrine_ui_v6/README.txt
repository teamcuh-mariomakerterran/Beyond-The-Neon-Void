BLACK DOCTRINE UI v6 — dialogue
dialogue_frame.png    320x96 hollow. Body text inset 12px.
name_plate.png        128x28 hollow. Speaker name inset 8px. Sits on the top-left, overlapping the frame by 8px.
portrait_frame.png    72x72 hollow. Portrait inset 8px. Left of the name plate.
next_arrow.png        16x16 amber. Bottom-right of the frame.
next_arrow_dim.png    same arrow, dim. Flip every 8 frames.
choice_idle.png       200x28
choice_active.png     200x28 amber lip
rumor_ticker.png      240x20 hollow strip for the news line
Godot: filter Nearest.
