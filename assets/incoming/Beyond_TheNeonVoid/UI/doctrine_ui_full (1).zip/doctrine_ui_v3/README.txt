BLACK DOCTRINE UI v3 — damage numbers + card shell
Daemon Caller minors stay as named in v2.

NUMBERS
sheets/numbers_dmg_16x20.png   cream, normal hit
sheets/numbers_crit_16x20.png  amber crit
sheets/numbers_heal_16x20.png  green heal
sheets/numbers_mp_16x20.png    cyan mp / special
Cell is 16x20, 12 glyphs, order 0-9 plus minus. Slice on 16x20, zero margin.
glyphs/ has the individuals. tags: tag_crit tag_heal tag_miss tag_block

CARDS
cards/card_frame.png          96x128 hollow doctrine frame
cards/card_back.png           same size, filled back
cards/card_trim_common.png    iron lip
cards/card_trim_uncommon.png  green lip
cards/card_trim_rare.png      cobalt lip
cards/card_trim_epic.png      amethyst lip
cards/card_trim_legendary.png gold lip
cards/cost_gem.png            16x16, sits on the top-left of the frame
cards/turn_chip.png           32 portrait well
cards/turn_chip_active.png    amber active-turn ring
cards/objective_popup.png     160x40 hollow plate

Godot: filter Nearest. Compose card as frame, then art in the well (inset 10px), then rarity trim, then cost gem.
