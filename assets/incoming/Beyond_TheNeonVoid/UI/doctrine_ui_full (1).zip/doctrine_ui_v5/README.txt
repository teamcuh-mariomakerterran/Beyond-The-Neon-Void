BLACK DOCTRINE UI v5 — shop money
soul_coin.png     24x24 gold disc, cyan soul core
microchip.png     24x24 lime pins, cyan die
price_tag.png     72x24 hollow tag, icon well on the left, number sits to the right of x=22
price_soul.png    tag with coin already seated
price_chip.png    tag with chip already seated
tab_buy.png       active lime
tab_sell.png      idle purple
sheets/currency_24.png  cell 24, order soul_coin microchip
Godot: filter Nearest. Price string uses the v3 cream number sheet.
