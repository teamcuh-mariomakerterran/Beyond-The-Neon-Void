BLACK DOCTRINE UI v7 — menu layer
PARTY
portrait_well.png            72x72 hollow, same as the dialogue portrait
equip_weapon/armor/accessory/trinket_empty.png   48x48, ghost mark
equip_*_filled.png           same slot, lime lip
jp_track.png jp_fill.png     96x12. Fill is a bar, clip it to the current JP.
job_locked job_unlocked job_mastered   40x40
learn_empty learn_known      32x32

INVENTORY
inv_cell.png                 40x40. Same well as a recipe slot.
count_badge.png              16x12 amber. Seat bottom-right. Number from the v3 cream sheet.
filter_all.png filter_gear.png

FORGE
recipe_slot.png              40x40
upgrade_arrow.png            16x16
evolves_chevron.png          24x16

FORMS
checkbox_off checkbox_on     16x16
slider_track.png             80x8
slider_knob.png              12x12
scrollbar.png                8x48
dropdown_arrow.png           12x12

MENUS
tooltip.png                  200x64 hollow
modal.png                    240x140 hollow
pause_plate.png              160x36
save_slot.png                220x40
save_slot_selected.png       same, lime lip

DISPATCH
mission_card.png             168x80 hollow
timer.png                    16x16
success_pips.png             48x10, five pips, three lit in the sample. Recolor in engine.

MATS
provisional names. Rename in manifest if the table already has ids.
scrap_plate neon_filament cryo_cell void_shard essence_vial plasma_core
microcoil chrome_rivet data_shard stim_residue soul_dust circuit_weave
sheet cell 24, that order.

GLYPHS
face_a face_b face_x face_y key_e key_space  16x16
Drop face_a into the interact prompt if that is the bind.

Godot: filter Nearest. Title logo is not in this drop. Wordmark is not locked.
