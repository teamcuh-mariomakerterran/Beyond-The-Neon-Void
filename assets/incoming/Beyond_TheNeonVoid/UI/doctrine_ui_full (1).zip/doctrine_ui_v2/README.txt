BLACK DOCTRINE UI v2 — real roster lock
Replaces the placeholder class and enemy names from v1. Weapons, statuses, rarity, HUD from v1 still stand.

ids are snake_case filenames. 64 cell, 0 margin on sheets. 32 is nearest half.
Godot: filter Nearest.

CLASSES (37) match the tier list.
SIGNATURES (34) paired in manifest.json pairs[]. Holo Summoner and Daemon Caller use summon icons, not a single signature. Droid Master uses the four build badges.

PROVISIONAL daemon minors (rename if the table already named them):
packet_rat, rent_due, null_choir, stack_overflow, glitch_saint
Big three are locked: saint_uptime, the_landlord, leviathan_null
Holo: iron_titan, static_wyrm, leviathan_feed

ENEMIES locked to the behavior list plus the existing 12:
gutter_punk chrome_hound riot_mech signal_jammer static_leech repo_man corpo_netrunner bomb_crawler sump_thing mourner mirror_unit auditor choir_cardinal
shift_warden choir_enforcer cantor_adept factory_marksman munitions_drone essence_wraith foreman
ally: assault_droid bulwark_droid medic_droid volt_droid sentry_turret
builds: build_assault build_bulwark build_medic build_volt
