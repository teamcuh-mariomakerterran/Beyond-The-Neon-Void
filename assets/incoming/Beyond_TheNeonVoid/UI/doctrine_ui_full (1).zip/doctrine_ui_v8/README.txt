BLACK DOCTRINE UI v8 — detailed mats + iso facing
Mats are 64 masters, 32 nearest halves. Same order as v7.
scrap_plate neon_filament cryo_cell void_shard essence_vial plasma_core
microcoil chrome_rivet data_shard stim_residue soul_dust circuit_weave

Facing is one chevron, four diagonals. The old face_n/e/s/w cardinals do not match a 2:1 map.
face_nw face_ne face_se face_sw
SE is the drawn master. The other three are flips of that same pixel set, so the head does not change.
Godot: filter Nearest.
