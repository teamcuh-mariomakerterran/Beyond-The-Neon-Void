BLACK DOCTRINE UI v4 — world loop
location_plate.png       192x36 hollow label. Drop the place name inset 8px.
undiscovered.png         24x24 ? diamond. Unmapped POI.
interact_glyph.png       24x24 press prompt. Swap the chevron for a controller face if you bind one.
minimap_frame.png        128x128 hollow. Map draws inset 10px.
player_arrow.png         16x16 cyan. Rotate in engine, do not redraw.
pin_city / poi / shop / quest / danger   24x32 teardrops.
sheets/pins_24x32.png    five pins, cell 24x32, order city poi shop quest danger.
quest_tracker_plate.png  160x28 hollow strip.
quest_check.png          done
quest_open.png           open
Godot: filter Nearest.
