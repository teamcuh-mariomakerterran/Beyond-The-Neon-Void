Approved painted mats: doctrine_ui_v8/mats_painted/
Order: scrap_plate neon_filament cryo_cell void_shard essence_vial plasma_core / microcoil chrome_rivet data_shard stim_residue soul_dust circuit_weave
Facing: doctrine_ui_v8/facing/ face_nw face_ne face_se face_sw
