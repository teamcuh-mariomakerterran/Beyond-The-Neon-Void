BLACK DOCTRINE UI — full drop
doctrine_ui/        wave 1 icons, frames, HUD, commands, stats
doctrine_ui_v2/     real classes, signatures, enemies, droids, summons
doctrine_ui_v3/     damage numbers, card shell, turn chips
doctrine_ui_v4/     world loop: location plate, pins, minimap, quest tracker
doctrine_ui_v5/     shop: soul coin, microchip, price tag, buy/sell
doctrine_ui_v6/     dialogue frame, name plate, portrait, choices
doctrine_ui_v7/     party, inventory, forge, forms, pause, dispatch, mats
doctrine_ui_v8/     facing arrows (pixel flips of the approved SE master) and mat masters
Facing order: face_nw face_ne face_se face_sw. SE is the master.
Godot filter: Nearest.
